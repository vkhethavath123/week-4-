package tissuefactory.commanddesignpattern;

public interface Command {
	public void execute();
}
